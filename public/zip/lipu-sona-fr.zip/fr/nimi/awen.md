---
sp: 󱤈
definition: gardé, protégé, conservé, sûr ; qui attend, qui persiste, qui reste
preverb: continuer à 
---