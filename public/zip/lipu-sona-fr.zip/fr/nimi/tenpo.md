---
sp: 󱥫
definition: temps, durée, moment, occasion, période, situation
---