---
sp: 󱤽
definition: -ième (nombre ordinal) ; nombre
---