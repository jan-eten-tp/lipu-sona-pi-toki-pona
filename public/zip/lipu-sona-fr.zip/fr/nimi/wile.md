---
sp: 󱥷
definition: devoir, avoir besoin de, requérir, vouloir, souhaiter
---