---
sp: 󱤶
definition: manger, boire, consommer, avaler, ingérer
---