---
sp: 󱥌
definition: donner, envoyer, mettre, fournir, émettre, lâcher
---