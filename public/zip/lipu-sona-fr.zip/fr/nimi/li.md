---
sp: 󱤧
definition: (indique le prédicat)
---