---
sp: 󱤛
definition: objet dur ; métal, pierre
---