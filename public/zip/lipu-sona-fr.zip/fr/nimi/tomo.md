---
sp: 󱥭
definition: espace intérieur, lieu couvert ; maison, bâtiment, édifice, chez soi, demeure ; pièce, chambre, salle
---