---
sp: 󱤠
definition: oreille ; entendre, écouter ; faire attention à, obéir
---