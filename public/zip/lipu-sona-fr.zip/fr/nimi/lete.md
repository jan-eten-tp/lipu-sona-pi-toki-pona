---
sp: 󱤦
definition: froid, frais ; cru
---