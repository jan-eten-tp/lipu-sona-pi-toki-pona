---
sp: 󱤭
definition: bras, main, organe tactile
---