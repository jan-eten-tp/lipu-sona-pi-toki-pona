---
sp: 󱥤
definition: soleil ; lumière, luminosité, lueur, radiance, éclat ; source de lumière
---