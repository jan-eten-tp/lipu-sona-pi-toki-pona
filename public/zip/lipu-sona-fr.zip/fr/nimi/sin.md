---
sp: 󱥝
definition: nouveau, frais ; encore un, de plus ; additionnel
---