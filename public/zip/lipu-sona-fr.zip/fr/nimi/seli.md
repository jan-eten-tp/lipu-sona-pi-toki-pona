---
sp: 󱥗
definition: feu ; élément de cuisson, réaction chimique, chaleur
---