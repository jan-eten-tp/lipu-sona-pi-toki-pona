---
sp: 󱥊
definition: objet long et dur ; branche, bâton, barre
---