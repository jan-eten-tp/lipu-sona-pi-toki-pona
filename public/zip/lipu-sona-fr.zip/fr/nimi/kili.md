---
sp: 󱤚
definition: fruit, légume, champignon
---