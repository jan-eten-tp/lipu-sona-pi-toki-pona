---
sp: 󱤢
definition: dormir, se reposer
---