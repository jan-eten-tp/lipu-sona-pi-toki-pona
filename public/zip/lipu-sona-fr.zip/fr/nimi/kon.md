---
sp: 󱤝
definition: air, souffle ; essence, esprit ; réalité cachée, agent invisible
---
