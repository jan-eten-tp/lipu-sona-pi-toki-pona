---
sp: 󱤙
definition: en utilisant, avec, au moyen de
---