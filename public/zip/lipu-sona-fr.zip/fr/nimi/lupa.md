---
sp: 󱤯
definition: trou, orifice ; porte, fenêtre
---