---
sp: 󱥣
definition: grand, lourd, long, large, gros ; important ; adulte
---