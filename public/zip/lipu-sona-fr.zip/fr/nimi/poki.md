---
sp: 󱥓
definition: contenant ; sac, bol, tasse, vase, récipient ; placard, tiroir
---