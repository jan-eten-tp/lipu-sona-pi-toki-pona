---
sp: 󱥴
definition: oiseau, animal ailé, créature volante
---