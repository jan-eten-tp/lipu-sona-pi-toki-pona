---
sp: 󱥃
definition: pied, jambe, organe locomoteur
---