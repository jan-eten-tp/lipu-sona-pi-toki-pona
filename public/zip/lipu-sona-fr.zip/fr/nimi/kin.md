---
sp: 󱥹
definition: en effet, aussi, également
---