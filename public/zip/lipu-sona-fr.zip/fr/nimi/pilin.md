---
sp: 󱥎
definition: cœur physique et émotionnel ; ressentir une émotion, une expérience directe
---