---
sp: 󱥈
definition: brisé, cassé, abîmé, bâclé, gâché
---