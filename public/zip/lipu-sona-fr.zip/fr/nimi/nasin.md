---
sp: 󱤿
definition: ichemin, voie ; manière, façon ; coutume, méthode, doctrine
---