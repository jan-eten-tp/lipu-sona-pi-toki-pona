---
sp: 󱥬
definition: communiquer, discuter, dire, parler, penser ; utiliser une langue ; bonjour
---