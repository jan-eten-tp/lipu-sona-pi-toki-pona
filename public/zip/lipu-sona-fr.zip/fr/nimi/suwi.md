---
sp: 󱥦
definition: doux, parfumé ; mignon, innocent, adorable 
---