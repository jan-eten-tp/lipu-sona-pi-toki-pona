---
sp: 󱥮
definition: séparer, couper
---