---
sp: 󱥀
definition: nez ; bosse, colline, montagne ; bouton, protubérance
---