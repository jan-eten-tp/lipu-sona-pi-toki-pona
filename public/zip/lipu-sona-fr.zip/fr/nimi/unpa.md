---
sp: 󱥯
definition: avoir des rapports sexuels
---