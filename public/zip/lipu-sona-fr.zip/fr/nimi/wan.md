---
sp: 󱥳
definition: unique, uni
---