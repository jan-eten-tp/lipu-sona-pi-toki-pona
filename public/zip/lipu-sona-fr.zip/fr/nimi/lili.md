---
sp: 󱤨
definition: petit, court ; peu, un peu ; jeune
---