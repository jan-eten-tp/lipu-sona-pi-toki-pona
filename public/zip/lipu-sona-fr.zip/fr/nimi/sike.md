---
sp: 󱥜
definition: objet rond ou circulaire ; balle, cercle, cycle, sphère, roue, anneau ; annuel
---