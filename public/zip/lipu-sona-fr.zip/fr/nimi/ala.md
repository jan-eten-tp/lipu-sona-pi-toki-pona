---
sp: 󱤂
definition: non, ne… pas ; rien, aucun, zéro
---