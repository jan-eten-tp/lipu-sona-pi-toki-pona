---
sp: 󱤁
definition: reptile, amphibien
---