---
sp: 󱥧
definition: de, provenant de, à cause de, parce que ; origine, cause
---