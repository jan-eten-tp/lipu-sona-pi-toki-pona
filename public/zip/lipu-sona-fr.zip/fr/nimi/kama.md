---
sp: 󱤖
definition: qui arrive, qui vient ; futur
preverb: devenir, parvenir à, réussir à
---