---
sp: 󱤬
definition: à, situé à, présent à, dans, sur ; réel, vrai, actuel
---