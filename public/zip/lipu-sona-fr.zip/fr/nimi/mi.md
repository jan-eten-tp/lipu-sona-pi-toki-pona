---
sp: 󱤴
definition: pronom de la première personne (je, moi, nous)
---