---
sp: 󱤘
definition: pouvoir, avoir le droit de ; possible
preverb: être capable de
---