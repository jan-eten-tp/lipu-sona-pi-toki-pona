---
sp: 󱥆
definition: pronom de la troisième personne (il·s, elle·s, eux, iel·s)
---