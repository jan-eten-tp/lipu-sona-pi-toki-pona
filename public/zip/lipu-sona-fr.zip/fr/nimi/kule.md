---
sp: 󱤞
definition: coloré, pigmenté, peint
---