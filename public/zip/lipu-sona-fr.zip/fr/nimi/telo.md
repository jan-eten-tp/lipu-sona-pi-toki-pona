---
sp: 󱥪
definition: eau, liquide, fluide ; boisson
---