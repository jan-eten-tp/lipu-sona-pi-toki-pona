---
sp: 󱥏
definition: noir, foncé, sombre
---