---
sp: 󱥵
definition: fort, puissant ; sûr, confiant ; énergique, intense
---