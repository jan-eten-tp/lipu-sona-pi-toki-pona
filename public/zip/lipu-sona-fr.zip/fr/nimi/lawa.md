---
sp: 󱤤
definition: tête, esprit ; dominer, diriger, guider, mener, posséder, prévoir, régler
---