---
sp: 󱥥
definition: surface horizontale, chose sur laquelle se reposer ou poser quelque chose
---