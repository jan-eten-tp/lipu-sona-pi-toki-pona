---
sp: 󱤹
definition: (cri ou communication d'un animal ; expression non verbale)
---