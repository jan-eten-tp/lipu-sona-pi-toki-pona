---
sp: 󱤏
definition: centre, contenu, intérieur, entre ; organe interne, estomac
---