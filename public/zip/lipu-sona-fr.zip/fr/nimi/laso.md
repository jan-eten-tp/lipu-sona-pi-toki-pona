---
sp: 󱤣
definition: bleu, vert
---