---
sp: 󱤆
definition: différent, altéré, changé, autre
---