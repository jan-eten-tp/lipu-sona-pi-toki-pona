---
sp: 󱤌
definition: chose, phénomène, objet, matière ; être, entité, personne
---