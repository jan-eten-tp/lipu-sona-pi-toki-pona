---
sp: 󱥛
definition: corps d'une personne ou d'un animal, état physique, torse
---