---
sp: 󱥒
definition: hanche, côté ; proximité, environs, à côté de, proche de
---