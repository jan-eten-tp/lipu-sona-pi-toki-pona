---
sp: 󱥲
definition: blanc, blanchâtre ; de couleur claire, pâle
---