---
sp: 󱥘
definition: forme, couche extérieure ; peau, écorce, pelure, coquille ; frontière, limite
---