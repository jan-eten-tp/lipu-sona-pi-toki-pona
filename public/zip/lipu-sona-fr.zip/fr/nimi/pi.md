---
sp: 󱥍
definition: (regroupe les modificateurs)
---