---
sp: 󱤪
definition: objet plat ; livre, document, carte, papier, site web
---