---
sp: 󱤺
definition: lune, astre, étoile
---