---
sp: 󱤍
definition: mauvais, négatif ; superflu, non essentiel, non pertinent
---