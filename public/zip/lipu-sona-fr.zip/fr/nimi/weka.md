---
sp: 󱥶
definition: absent, éloigné, ignoré
---