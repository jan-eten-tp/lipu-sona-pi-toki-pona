---
sp: 󱥠
definition: image, représentation, symbole, marque, écriture
---