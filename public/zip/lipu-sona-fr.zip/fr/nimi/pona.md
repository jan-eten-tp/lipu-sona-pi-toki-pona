---
sp: 󱥔
definition: bon, positif, utile ; amical, paisible ; simple
---