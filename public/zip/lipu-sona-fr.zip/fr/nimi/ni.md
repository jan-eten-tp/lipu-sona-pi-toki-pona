---
sp: 󱥁
definition: ce, cet, cette, ces, ceci, cela, ceux-ci, ceux-là
---