---
sp: 󱤒
definition: jaune, jaunâtre
---
