---
sp: 󱥑
definition: insecte, arachnide
---