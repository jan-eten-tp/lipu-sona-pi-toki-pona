---
sp: 󱤷
definition: mort, mourant
---