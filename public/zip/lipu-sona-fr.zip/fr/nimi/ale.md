---
sp: 󱤄
definition: tout, tous, chaque ; innombrable ; abondant, généreux ; vie, univers
---