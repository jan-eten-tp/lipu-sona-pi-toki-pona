---
sp: 󱥇
definition: commencer, débuter ; ouvrir ; allumer, enclencher
---