---
sp: 󱥩
definition: à, allant à, vers ; pour ; du point de vue de ; en mouvement, animé
---