---
sp: 󱥨
definition: mais, cependant ; seulement
---