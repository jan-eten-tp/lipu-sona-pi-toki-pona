---
sp: 󱥞
definition: pronom de la deuxième personne (tu, toi, vous)
---