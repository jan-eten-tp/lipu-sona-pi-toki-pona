---
sp: 󱥰
definition: bouche, lèvres, cavité buccale, mâchoire
---