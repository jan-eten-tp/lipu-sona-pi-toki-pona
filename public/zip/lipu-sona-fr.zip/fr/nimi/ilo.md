---
sp: 󱤎
definition: outil, instrument, équipement, machine, appareil
---