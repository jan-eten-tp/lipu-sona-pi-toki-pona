---
sp: 󱤡
definition: (entre une proposition subordonnée établissant le contexte et la phrase principale)
---