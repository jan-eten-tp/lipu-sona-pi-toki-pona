---
sp: 󱤾
definition: étrange, insolite ; ivre
---