---
sp: 󱥚
definition: dessus, haut, partie supérieure, chose élevée ; divin, sacré, surnaturel, qui inspire le respect et la crainte
---