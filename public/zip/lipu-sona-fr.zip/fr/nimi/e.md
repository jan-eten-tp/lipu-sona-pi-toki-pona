---
sp: 󱤉
definition: (indique le complément d'objet direct)
---