---
sp: 󱤰
definition: terre, sol ; monde, extérieur, lieu en plein air ; pays, territoire
---