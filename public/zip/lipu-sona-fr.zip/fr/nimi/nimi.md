---
sp: 󱥂
definition: mot, nom
---
