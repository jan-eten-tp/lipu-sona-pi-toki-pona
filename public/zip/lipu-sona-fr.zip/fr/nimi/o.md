---
sp: 󱥄
definition: (vocatif, impératif ou optatif)
---