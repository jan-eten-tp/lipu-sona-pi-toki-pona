---
sp: 󱤋
definition: marché, boutique, foire, magasin ; commerce, transaction marchande ou monétaire
---