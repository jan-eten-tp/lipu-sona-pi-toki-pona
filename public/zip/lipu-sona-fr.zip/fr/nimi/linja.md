---
sp: 󱤩
definition: objet long et flexible ; corde, cheveux, fil, ligne
---