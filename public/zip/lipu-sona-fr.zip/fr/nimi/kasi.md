---
sp: 󱤗
definition: plante, végétation ; herbe, feuille
---