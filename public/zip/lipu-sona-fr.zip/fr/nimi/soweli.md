---
sp: 󱥢
definition: animal, mammifère terrestre
---