---
sp: 󱤸
definition: dos, postérieur ; derrière, arrière
---