---
sp: 󱤱
definition: parent, ancêtre ; créateur ; gardien, celui ou celle qui prend soin
---