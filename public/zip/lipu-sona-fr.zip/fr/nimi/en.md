---
sp: 󱤊
definition: (entre plusieurs sujets)
---