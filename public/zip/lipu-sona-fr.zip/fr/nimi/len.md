---
sp: 󱤥
definition: tissu, textile ; linge, vêtement ; couverture, rideau d'intimité
---