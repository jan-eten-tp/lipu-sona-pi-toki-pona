---
sp: 󱤲
definition: argent, économies, richesse ; grand animal domestiqué, bétail
---