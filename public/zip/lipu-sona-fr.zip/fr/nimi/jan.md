---
sp: 󱤑
definition: être humain, personne, quelqu'un
---