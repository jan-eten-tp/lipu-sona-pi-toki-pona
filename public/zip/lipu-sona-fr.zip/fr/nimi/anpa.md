---
sp: 󱤅
definition: incliné vers le bas, en bas ; humble, modeste, dépendant ; partie inférieure, sous, en dessous ; sol, fond ; inférieur, descendant
---