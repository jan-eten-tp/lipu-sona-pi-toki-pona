---
sp: 󱥉
definition: faire, agir sur, travailler ; construire, créer, préparer
---