---
sp: 󱥙
definition: quoi ? quel ? (indique l'information manquante dans une question)
---