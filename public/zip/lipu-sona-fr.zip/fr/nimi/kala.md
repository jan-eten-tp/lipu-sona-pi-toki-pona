---
sp: 󱤔
definition: poisson, animal sous-marin, créature aquatique
---