---
sp: 󱤓
definition: avoir, porter, contenir, tenir
---