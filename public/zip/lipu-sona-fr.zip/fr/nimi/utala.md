---
sp: 󱥱
definition: combat, défi ; se battre contre, lutter contre
---