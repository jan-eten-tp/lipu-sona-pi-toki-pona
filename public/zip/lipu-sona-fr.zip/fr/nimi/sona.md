---
sp: 󱥡
definition: savoir, connaître, avoir des informations sur
preverb: savoir comment
---
