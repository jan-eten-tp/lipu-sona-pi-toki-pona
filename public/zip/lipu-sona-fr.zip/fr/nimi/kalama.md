---
sp: 󱤕
definition: émettre un son ; réciter, proférer
---