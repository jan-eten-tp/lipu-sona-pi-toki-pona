---
sp: 󱤼
definition: beaucoup de, plusieurs, plus de ; très ; quantité
---