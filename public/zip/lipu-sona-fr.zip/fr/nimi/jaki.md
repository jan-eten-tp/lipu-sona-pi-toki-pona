---
sp: 󱤐
definition: dégoûtant, obscène, malade, toxique, impur, insalubre, sale
---