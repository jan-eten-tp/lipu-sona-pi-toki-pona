---
sp: 󱤟
definition: communauté, groupe, nation, société, tribu, compagnie
---