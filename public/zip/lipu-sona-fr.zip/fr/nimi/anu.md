---
sp: 󱤇
definition: ou
---