---
sp: 󱤫
definition: rouge, rougeâtre
---