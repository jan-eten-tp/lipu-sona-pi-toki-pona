---
sp: 󱤃
definition: chasser, cueillir ; fouiller, chercher
---