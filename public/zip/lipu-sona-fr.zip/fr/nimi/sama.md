---
sp: 󱥖
definition: même, semblable ; l'un l'autre ; adelphe, pair, compagnon, homologue ; comme
---