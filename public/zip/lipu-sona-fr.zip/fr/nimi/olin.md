---
sp: 󱥅
definition: aimer, respecter, compatir, montrer de l'affection pour
---