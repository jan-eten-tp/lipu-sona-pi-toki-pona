---
sp: 󱥋
definition: céréale ; riz, blé, orge, maïs, avoine ; pain, pâtes
---