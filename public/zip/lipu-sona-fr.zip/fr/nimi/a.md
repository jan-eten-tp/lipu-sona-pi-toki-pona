---
sp: 󱤀
definition: (emphase, émotion, exclamation, confirmation)
---