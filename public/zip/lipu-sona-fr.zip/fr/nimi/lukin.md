---
sp: 󱤮
definition: œil ; regarder, voir, examiner, observer, lire, surveiller
preverb: chercher à, essayer
---