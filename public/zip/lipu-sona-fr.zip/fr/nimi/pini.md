---
sp: 󱥐
definition: fini, passé, terminé, achevé
---