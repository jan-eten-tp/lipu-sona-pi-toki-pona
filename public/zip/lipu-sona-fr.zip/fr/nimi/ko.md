---
sp: 󱤜
definition: argile, pâte, substance collante, semi-solide ; poudre
---