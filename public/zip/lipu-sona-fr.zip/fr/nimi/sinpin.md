---
sp: 󱥟
definition: avant ; visage, front ; mur
---