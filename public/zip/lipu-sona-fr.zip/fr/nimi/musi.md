---
sp: 󱤻
definition: artistique, divertissant ; frivole, ludique, récréatif
---  