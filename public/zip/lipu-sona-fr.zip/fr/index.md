---
title: lipu sona mi pi toki pona
language: toki Kanse / français # name of language in toki pona / name of language in the language
lang: fr
author: jan Aleko # this is the name you'd like to be credited with
authorlink: # something you'd like your name to link to
previous: précédent
index: sommaire
next: suivant
---

::index-layout

  ::bg-box

  ## leçons
  <!-- this will automatically generate the list of courses -->
  :lesson-list{:lang="lang"}

  ::

#right-side

  ::bg-box

  ## autres langues
  <!-- this will automatically generate the list of languages -->
  :language-list{:lang="lang"}

  ::

  <br />

  ::bg-box

  ## ressources
  - la plupart des définitions viennent de [lipu Linku](https://linku.la/)
  - je me suis référé·e à ces leçons \
  quand je me sentais perdu·e :
    - [nasin toki pona de jan Juli (en anglais)](https://github.com/kilipan/nasin-toki)
    - [ lipu pu de jan Sonja (disponible en français) ](https://tokipona.org/)
  - d’autres bons cours :
    - [les cours de gregdan (en anglais) ](https://mun.la/toki-pona/)
    - [le cours de devurandom (en anglais)](https://lipu-sona.pona.la/)

  ::

::
