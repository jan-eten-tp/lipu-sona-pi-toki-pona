---
sp: 󱤨
definition: piccolo, minuscolo, basso; poco; leggermente; giovane
---