---
sp: 󱤩
definition: cosa lunga e flessibile; corda, capello, filo
---