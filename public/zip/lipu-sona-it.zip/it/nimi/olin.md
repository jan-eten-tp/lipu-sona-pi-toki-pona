---
sp: 󱥅
definition: amare, provare compassione, rispettare, mostrare affetto
---