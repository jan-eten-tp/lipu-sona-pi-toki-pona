---
sp: 󱥞
definition: pronome di seconda persona (tu, te, voi)
---