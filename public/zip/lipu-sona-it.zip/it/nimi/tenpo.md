---
sp: 󱥫
definition: tempo, durata, momento, occasione, periodo, situazione
---