---
sp: 󱥩
definition: andare a, verso; per; dalla prospettiva di; muoversi
---