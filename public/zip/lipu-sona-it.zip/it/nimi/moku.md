---
sp: 󱤶
definition: mangiare, bere, consumare, ingoiare, digerire
---