---
sp: 󱥆
definition: pronome di terza persona (lui, lei, loro)
---