---
sp: 󱤼
definition: molti, parecchi, di più, assai, numerosi, molto; quantità
---