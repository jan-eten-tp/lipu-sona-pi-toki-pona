---
sp: 󱤏
definition: centro, contenuto, dentro, in mezzo; organo interno, stomaco
---