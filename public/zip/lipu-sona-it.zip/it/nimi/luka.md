---
sp: 󱤭
definition: braccio, mano, organo tattile
---