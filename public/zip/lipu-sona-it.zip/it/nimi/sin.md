---
sp: 󱥝
definition: nuovo, fresco; aggiuntivo, ancora, extra
---