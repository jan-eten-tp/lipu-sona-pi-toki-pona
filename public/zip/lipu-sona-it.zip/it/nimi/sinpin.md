---
sp: 󱥟
definition: faccia, davanti, frontale, muro
---