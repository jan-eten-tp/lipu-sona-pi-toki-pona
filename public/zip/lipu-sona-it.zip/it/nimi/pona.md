---
sp: 󱥔
definition: buono, positivo, utile; amichevole, pacifico; semplice
---