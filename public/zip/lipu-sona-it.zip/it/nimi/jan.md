---
sp: 󱤑
definition: essere umano, persona
---