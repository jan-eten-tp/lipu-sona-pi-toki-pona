---
sp: 󱤿
definition: modo, abitudine, dottrina, metodo, percorso, strada, via
---