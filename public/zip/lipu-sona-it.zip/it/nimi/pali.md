---
sp: 󱥉
definition: fare, agire, lavorare; costruire, creare, preparare
---