---
sp: 󱤅
definition: inchinato, verso il basso, umile, inferiormente, dipendente; fondo, parte inferiore, sotto, pavimento; basso, inferiore
---