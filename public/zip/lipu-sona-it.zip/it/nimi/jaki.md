---
sp: 󱤐
definition: disgustoso, osceno, nauseabondo, tossico, sporco, insalubre
---