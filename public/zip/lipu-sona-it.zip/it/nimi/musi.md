---
sp: 󱤻
definition: artistico, intrattenente, divertente, ricreativo, giocoso
---  