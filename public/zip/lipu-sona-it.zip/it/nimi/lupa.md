---
sp: 󱤯
definition: porta, buco, orifizio, finestra
---