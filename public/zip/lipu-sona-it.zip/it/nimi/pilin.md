---
sp: 󱥎
definition: cuore; sentimento
---