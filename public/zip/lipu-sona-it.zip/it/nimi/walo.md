---
sp: 󱥲
definition: bianco, biancastro; chiaro, pallido
---