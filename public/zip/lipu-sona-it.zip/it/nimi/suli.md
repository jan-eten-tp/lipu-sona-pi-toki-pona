---
sp: 󱥣
definition: grande, pesante, grosso, lungo, alto; importante; adulto
---