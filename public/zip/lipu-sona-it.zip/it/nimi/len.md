---
sp: 󱤥
definition: panno, abbigliamento, tessuto; copertura, strato di privacy
---