---
sp: 󱥌
definition: dare, inviare, emettere, provvedere, mettere, rilasciare
---