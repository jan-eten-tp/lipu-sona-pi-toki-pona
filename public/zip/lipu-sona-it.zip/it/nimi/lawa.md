---
sp: 󱤤
definition: testa, mente; controllare, dirigere, guidare, comandare, possedere, pianificare, regolare, governare
---