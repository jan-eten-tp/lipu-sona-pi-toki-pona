---
sp: 󱤸
definition: dietro, indietro, posteriore
---