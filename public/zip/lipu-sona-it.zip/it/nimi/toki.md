---
sp: 󱥬
definition: comunicare, dire, parlare, discutere, conversare, ragionare; ciao
---