---
sp: 󱥥
definition: superficie orizzontale, cosa su cui appoggiare qualcosa
---