---
sp: 󱥙
definition: (indica l’informazione mancante in una domanda)
---