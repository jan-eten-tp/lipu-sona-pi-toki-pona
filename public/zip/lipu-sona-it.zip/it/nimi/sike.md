---
sp: 󱥜
definition: tondo, circolare; palla, cerchio, ciclo, sfera, ruota; annuale
---