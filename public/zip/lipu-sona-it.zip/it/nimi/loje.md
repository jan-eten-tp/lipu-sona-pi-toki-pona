---
sp: 󱤫
definition: rosso, rossastro
---