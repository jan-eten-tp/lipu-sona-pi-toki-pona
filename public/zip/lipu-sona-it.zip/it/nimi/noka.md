---
sp: 󱥃
definition: piede, gamba, organo di locomozione
---