---
sp: 󱤊
definition: (tra soggetti aggiuntivi)
---