---
sp: 󱤃
definition: cacciare, procacciare, cercare
---