---
sp: 󱤎
definition: utensile, strumento, macchina, dispositivo
---