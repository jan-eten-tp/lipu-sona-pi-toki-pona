---
sp: 󱤘
definition: potere, avere il permesso, essere capace; possibile
preverb: essere in grado di
---