---
sp: 󱤉
definition: introduce il complemento oggetto
---