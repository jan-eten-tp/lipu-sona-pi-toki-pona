---
sp: 󱥘
definition: forma esterna, strato esteriore; corteccia, buccia, guscio, pelle; confine
---