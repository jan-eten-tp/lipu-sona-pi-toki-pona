---
sp: 󱤚
definition: frutta, verdura, fungo
---