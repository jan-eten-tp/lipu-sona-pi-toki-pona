---
sp: 󱥛
definition: corpo (di persona o animale), stato fisico, torso
---