---
sp: 󱥶
definition: assente, mancante, ignorato
---