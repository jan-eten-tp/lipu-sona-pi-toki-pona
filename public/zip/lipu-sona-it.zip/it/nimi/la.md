---
sp: 󱤡
definition: (tra l’espressione di contesto e la frase principale)
---