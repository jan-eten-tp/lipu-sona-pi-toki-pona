---
sp: 󱥠
definition: immagine, figura, rappresentazione, simbolo, segno, scrittura
---