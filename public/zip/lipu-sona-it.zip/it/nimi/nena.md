---
sp: 󱥀
definition: protuberanza, pulsante, collina, montagna, naso
---