---
sp: 󱤜
definition: argilla, forma aderente, impasto, semisolido, polvere
---