---
sp: 󱥧
definition: da, a causa di; origine, causa
---