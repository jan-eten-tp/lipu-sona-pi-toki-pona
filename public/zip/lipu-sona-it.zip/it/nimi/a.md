---
sp: 󱤀
definition: (enfasi, emozione, o conferma)
---