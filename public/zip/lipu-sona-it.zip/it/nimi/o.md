---
sp: 󱥄
definition: (vocativo, imperativo, o ottativo)
---