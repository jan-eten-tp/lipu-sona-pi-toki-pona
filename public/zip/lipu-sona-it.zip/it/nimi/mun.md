---
sp: 󱤺
definition: luna, oggetto del cielo notturno, stella
---