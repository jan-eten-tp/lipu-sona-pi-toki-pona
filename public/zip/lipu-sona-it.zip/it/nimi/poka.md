---
sp: 󱥒
definition: fianco, lato; vicino, accanto, nelle vicinanze
---