---
sp: 󱤓
definition: avere, portare, contenere, tenere
---