---
sp: 󱥨
definition: ma, tuttavia, solo
---