---
sp: 󱤈
definition: rimanere, conservare, protetto, salvo, aspettare, stare
preverb: continuare a
---