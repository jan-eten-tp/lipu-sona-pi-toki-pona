---
sp: 󱤛
definition: oggetto duro, metallo, roccia, pietra
---