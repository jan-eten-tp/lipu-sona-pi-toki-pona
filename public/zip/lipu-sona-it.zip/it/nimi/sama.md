---
sp: 󱥖
definition: uguale, simile; reciproco; fratello, pari, compagno; come, stesso
---