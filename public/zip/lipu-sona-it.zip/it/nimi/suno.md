---
sp: 󱥤
definition: sole; luce, luminosità, bagliore, splendore; fonte di luce
---