---
sp: 󱤾
definition: inconsueto, strano; sciocco; ubriaco, intossicato
---