---
sp: 󱤠
definition: orecchio; sentire, ascoltare; fare attenzione, obbedire
---