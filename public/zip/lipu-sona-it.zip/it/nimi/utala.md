---
sp: 󱥱
definition: battaglia, sfida, competizione, lotta
---