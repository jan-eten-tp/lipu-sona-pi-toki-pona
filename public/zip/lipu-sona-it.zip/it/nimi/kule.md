---
sp: 󱤞
definition: colorato, pigmentato, dipinto
---