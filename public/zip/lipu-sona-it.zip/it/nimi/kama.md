---
sp: 󱤖
definition: arrivare, venire, futuro, convocato
preverb: diventare, riuscire a
---