---
sp: 󱥗
definition: fuoco; elemento di cottura, reazione chimica, fonte di calore
---