---
sp: 󱤇
definition: (forma una congiunzione disgiuntiva)
---