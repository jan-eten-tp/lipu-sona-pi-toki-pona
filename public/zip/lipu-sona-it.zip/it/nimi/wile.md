---
sp: 󱥷
definition: dovere, bisognare, richiedere, volere, desiderare
preverb: volere, necessitare
---