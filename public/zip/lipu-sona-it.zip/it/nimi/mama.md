---
sp: 󱤱
definition: genitore, antenato; creatore, autore; custode, mantenitore
---