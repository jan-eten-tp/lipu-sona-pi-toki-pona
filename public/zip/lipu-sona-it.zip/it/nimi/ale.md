---
sp: 󱤄
definition: tutto; abbondante, innumerevole, copioso, ogni; abbondanza, tutto, vita, universo
---