---
sp: 󱥍
definition: raggruppa i modificatori
---