---
sp: 󱤂
definition: no, non, zero; niente
---