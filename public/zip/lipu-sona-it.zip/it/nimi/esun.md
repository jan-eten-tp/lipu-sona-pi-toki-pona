---
sp: 󱤋
definition: mercato, negozio, fiera, bazar, transazione commerciale
---