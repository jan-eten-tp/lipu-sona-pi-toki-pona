---
sp: 󱥁
definition: quello, questo
---