---
sp: 󱤔
definition: pesce, animale marino, creatura acquatica
---