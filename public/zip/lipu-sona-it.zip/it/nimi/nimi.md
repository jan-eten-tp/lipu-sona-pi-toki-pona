---
sp: 󱥂
definition: nome, parola
---
