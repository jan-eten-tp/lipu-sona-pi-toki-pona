---
sp: 󱥪
definition: acqua, liquido, fluido, sostanza bagnata; bevanda
---