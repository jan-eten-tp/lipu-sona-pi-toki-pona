---
sp: 󱤷
definition: morto, moribondo
---