---
sp: 󱥡
definition: sapere, essere abile, essere saggio, avere informazioni
preverb: sapere come
---