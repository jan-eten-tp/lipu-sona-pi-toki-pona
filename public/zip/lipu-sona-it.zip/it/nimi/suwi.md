---
sp: 󱥦
definition: dolce, fragrante; carino, innocente, adorabile 
---