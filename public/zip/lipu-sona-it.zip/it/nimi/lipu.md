---
sp: 󱤪
definition: oggetto piatto; libro, documento, carta, pagina, sito internet
---