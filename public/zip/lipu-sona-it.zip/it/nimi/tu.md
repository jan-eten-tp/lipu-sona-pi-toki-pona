---
sp: 󱥮
definition: separato, tagliato
---