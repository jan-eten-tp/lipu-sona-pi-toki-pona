---
sp: 󱤆
definition: diverso, alterato, cambiato, altro
---