---
sp: 󱥳
definition: singolo, unito
---