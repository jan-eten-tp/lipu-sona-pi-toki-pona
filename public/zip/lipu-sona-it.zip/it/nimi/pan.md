---
sp: 󱥋
definition: cereale, grano; orzo, mais, avena, riso, frumento; pane, pasta
---