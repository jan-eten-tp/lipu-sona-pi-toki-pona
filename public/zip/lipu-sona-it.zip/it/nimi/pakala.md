---
sp: 󱥈
definition: rovinato, rotto, danneggiato, leso, incasinato
---