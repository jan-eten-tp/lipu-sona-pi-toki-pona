---
sp: 󱥰
definition: bocca, labbra, cavità orale, mandibola
---