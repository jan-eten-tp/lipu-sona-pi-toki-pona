---
sp: 󱤌
definition: cosa, fenomeno, oggetto, materia, qualcosa; essere, entità, qualcuno
---