---
sp: 󱥚
definition: area superiore, parte in alto, qualcosa di elevato; maestoso, divino, sacro, soprannaturale
---