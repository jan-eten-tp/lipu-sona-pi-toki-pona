---
sp: 󱤙
definition: utilizzare, per mezzo di
---