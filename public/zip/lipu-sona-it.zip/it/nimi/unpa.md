---
sp: 󱥯
definition: avere relazioni sessuali
---