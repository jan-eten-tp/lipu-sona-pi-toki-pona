---
sp: 󱤁
definition: rettile, anfibio
---