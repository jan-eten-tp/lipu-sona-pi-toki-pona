---
sp: 󱤝
definition: aria, respiro; essenza, spirito; realtà nascosta, agente invisibile
---
