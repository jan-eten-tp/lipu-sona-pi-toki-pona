---
sp: 󱤕
definition: produrre un suono; recitare, pronunciare ad alta voce
---