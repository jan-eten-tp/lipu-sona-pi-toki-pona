---
sp: 󱤗
definition: pianta, vegetazione; erba, foglia
---