---
sp: 󱥹
definition: infatti, pure, anche
---