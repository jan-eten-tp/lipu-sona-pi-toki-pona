---
sp: 󱥐
definition: tempo fa, completato, terminato, finito, passato
---