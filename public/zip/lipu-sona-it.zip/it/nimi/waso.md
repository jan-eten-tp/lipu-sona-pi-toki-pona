---
sp: 󱥴
definition: uccello, volatile, animale alato
---