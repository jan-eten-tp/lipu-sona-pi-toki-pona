---
sp: 󱥏
definition: nero, scuro, ombroso
---