---
sp: 󱥑
definition: insetto, formica, ragno
---