---
sp: 󱤬
definition: situato in, presente in; reale, vero, esistente
---