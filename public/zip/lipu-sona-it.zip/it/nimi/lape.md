---
sp: 󱤢
definition: dormire, riposare
---