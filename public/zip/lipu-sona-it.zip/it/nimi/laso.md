---
sp: 󱤣
definition: blu, verde
---