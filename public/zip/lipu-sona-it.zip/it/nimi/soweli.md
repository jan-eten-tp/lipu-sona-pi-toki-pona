---
sp: 󱥢
definition: animale, bestia, mammifero di terra
---