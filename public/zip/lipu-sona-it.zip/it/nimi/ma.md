---
sp: 󱤰
definition: terra; all’aperto, mondo; paese, territorio; suolo
---