---
sp: 󱥓
definition: contenitore, borsa, ciotola, scatola, tazza, cassetto, armadio, recipiente
---