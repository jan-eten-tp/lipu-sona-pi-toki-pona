---
sp: 󱤴
definition: pronome di prima persona (io, me, noi)
---