---
sp: 󱤍
definition: cattivo, negativo; non essenziale, irrilevante
---