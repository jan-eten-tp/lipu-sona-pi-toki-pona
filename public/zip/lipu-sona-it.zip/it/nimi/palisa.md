---
sp: 󱥊
definition: cosa lunga e dura; ramo, bacchetta, bastone
---