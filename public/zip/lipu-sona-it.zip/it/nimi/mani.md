---
sp: 󱤲
definition: soldi, contanti, risparmi, ricchezza; grande animale domestico
---