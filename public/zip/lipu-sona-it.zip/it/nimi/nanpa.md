---
sp: 󱤽
definition: (particella per i numeri ordinali); numero
---