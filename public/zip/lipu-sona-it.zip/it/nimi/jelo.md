---
sp: 󱤒
definition: giallo, giallastro
---
