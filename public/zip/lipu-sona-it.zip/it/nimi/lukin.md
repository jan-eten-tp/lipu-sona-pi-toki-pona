---
sp: 󱤮
definition: occhio; guardare, vedere, esaminare, osservare, leggere; cercare
preverb: provare a
---