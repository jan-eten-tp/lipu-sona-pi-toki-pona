---
sp: 󱤟
definition: comunità, compagnia, gruppo, nazione, società, tribù
---