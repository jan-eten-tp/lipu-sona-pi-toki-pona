---
sp: 󱥵
definition: forte, potente; sicuro, energetico, intenso
---