---
sp: 󱥭
definition: spazio interno; edificio, casa, costruzione, stanza
---