---
sp: 󱥕
definition: interagire con il libro ufficiale di toki pona
---