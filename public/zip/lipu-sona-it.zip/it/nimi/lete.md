---
sp: 󱤦
definition: freddo, fresco; non cotto, crudo
---