---
sp: 󱥇
definition: iniziare, cominciare; aprire; accendere
---