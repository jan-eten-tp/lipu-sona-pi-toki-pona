---
sp: 󱤧
definition: introduce il predicato
---