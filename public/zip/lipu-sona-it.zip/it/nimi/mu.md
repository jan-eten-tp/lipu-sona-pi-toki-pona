---
sp: 󱤹
definition: verso o comunicazione animale; vocalizzazione non verbale
---