---
title: lipu sona mi pi toki pona
language: toki Italija / italiano
lang: it
author: mun Sijala
authorlink: https://youtu.be/UUFkByJz9Go
previous: indietro
index: indice
next: avanti
particle: particle
preverb: pv.
preposition: preposition
number: number
---

::index-layout

  ::bg-box
  ## lezioni
  :lesson-list{:lang="lang"}
  ::

#right-side

  ::bg-box
  ## altre lingue
  :language-list{:lang="lang"}
  ::

  <br />

  ::bg-box
  ## risorse
  - la maggior parte delle definizioni provengono da [lipu Linku](https://linku.la/)
  - ho preso ispirazione da queste risorse:
    - [nasin toki di jan Juli](https://github.com/kilipan/nasin-toki)
    - [lipu pu di jan Sonja](https://tokipona.org/)
  - altri ottimi corsi:
    - [gregdan's course](https://mun.la/toki-pona/) 
    - [devurandom's course](https://lipu-sona.pona.la/)
  ::
::