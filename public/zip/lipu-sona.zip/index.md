---
title: lipu sona mi pi toki pona
language: toki Inli / english
author: soweli Tesa
---

::index-layout

## lessons
:lesson-list{:lang="language"}

#right-side

## other languages
:language-list{:lang="language"}

[how to help translate this course](/translate)

## other resources

- most definitions come from [lipu Linku](https://linku.la/)
- i looked to these resources when i felt lost:
  - [nasin toki by jan Juli](https://github.com/kilipan/nasin-toki)
  - [lipu pu by jan Sonja](https://tokipona.org/)
- other good courses: 
  - [gregdan's course](https://mun.la/toki-pona/) 
  - [devurandom's course](https://lipu-sona.pona.la/)

<br />

:download-button[pdf download]{link="pdf/lipu-sona.pdf"}

::

