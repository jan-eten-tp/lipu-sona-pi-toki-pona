---
sp: 󱥧
definition: cause, origin, reason
preposition: from, because of
---