---
sp: 󱥍
particle: regroups modifiers
---