---
sp: 󱤉
particle: marks the direct object
---