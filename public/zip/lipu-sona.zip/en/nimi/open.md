---
sp: 󱥇
definition: begin, start, open, turn on; beginning
---
<!-- open is the beginning. it's when things begin, when they are started. open is the act of beginning something, opening it, turning it on. -->