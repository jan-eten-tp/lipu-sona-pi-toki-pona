---
sp: 󱥒
definition: hip, side; next to, nearby, vicinity
---
<!-- poka is the things beside something. it's the things that are nearby. poka can describe metaphorical closeness too. i have friends who live very far away from me, but emotionally they can be poka. -->