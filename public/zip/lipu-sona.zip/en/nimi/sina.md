---
sp: 󱥞
definition: second-person pronoun (you)
---
<!-- you is a second-person pronoun. it talks about you and y'all, the group you're part of. -->