---
sp: 󱤡
particle: between the context phrase/sentence and the main sentence
---