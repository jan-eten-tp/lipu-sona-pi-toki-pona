---
sp: 󱤷
definition: death, dead, die, dying; kill, murder
---
<!-- moli is death and dying. you generally can't recover from moli unless you're a gamer who can't die they just respawn -->