---
sp: 󱤖
definition: arrive, approach, summon; future
preverb: to become
---
<!-- kama is the arrival from one state to another. this can be everything from your physical location, to your state of being like your job, mood, health, etc., and it could be lots of other things.

when sina kama e ijo, you are summoning the ijo. you are making it go from the state of not being present to being present. -->