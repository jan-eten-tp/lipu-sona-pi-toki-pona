---
sp: 󱥀
definition: protuberance; bump, button, hill, nose
---
<!-- nena is bumps. things that stick out of something. nenas can be sharp or rounded. -->