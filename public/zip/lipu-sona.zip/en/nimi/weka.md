---
sp: 󱥶
definition: absent, away, distant; remove, get rid of
---
