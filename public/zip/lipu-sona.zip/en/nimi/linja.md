---
sp: 󱤩
definition: long and flexible thing; rope, yarn, hair, fur, line, strand
---
<!-- linja is about squiggly long stuff. it's about long things which either can or look like they can be moved flexibly, like rope, hair, or lines on paper. a river *could* be described as a linja, because when you see it from above it looks very linja-y. obviously you can't *actually* move a river flexibly though, you're not god. -->