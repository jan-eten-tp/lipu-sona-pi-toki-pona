---
sp: 󱥚
definition: up, top, above, highest part; divine, sacred, supernatural; awesome, inspiring, excelling
---
<!-- sewi is both about the sky and things above, and about divine or incredible things. the idea of things that are high up, supernatural things, and incredible stuff, are all interconnected. -->