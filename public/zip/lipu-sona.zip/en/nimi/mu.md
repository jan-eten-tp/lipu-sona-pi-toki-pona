---
sp: 󱤹
definition: animal noise or communication; non-speech vocalization
---
<!-- mu is meow -->