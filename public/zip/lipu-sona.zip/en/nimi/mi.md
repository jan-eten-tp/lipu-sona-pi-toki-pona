---
sp: 󱤴
definition: first-person pronoun (i, me, we, us)
---
<!-- mi is a first-person pronoun. it talks about me and us, the group i'm speaking for. -->