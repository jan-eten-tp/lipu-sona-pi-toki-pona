---
sp: 󱥭
definition: indoor space or shelter e.g. room, building, home, tent, shack
---