---
sp: 󱥭
definition: indoor space, shelter; room, building, home, tent, shack
---