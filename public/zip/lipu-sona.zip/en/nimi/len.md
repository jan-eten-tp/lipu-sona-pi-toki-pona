---
sp: 󱤥
definition: cloth, fabric, textile; hidden, secret, covered, private
---
<!-- len is about covering stuff up. it's about clothing and secrecy.  -->