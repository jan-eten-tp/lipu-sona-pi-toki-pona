---
sp: 󱤓
definition: hold, carry, possess, contain, own
---
<!-- jo is about ownership, possession, or physically holding things. all of these are the same thing. -->