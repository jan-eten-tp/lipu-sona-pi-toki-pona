---
sp: 󱥌
definition: give, send, emit, provide, put, release; gift, present
---
<!-- pana is the act of giving, releasing, emitting. you can give things metaphorically, like good feelings. -->