---
sp: 󱥦
definition: sweet, fragrant; cute, adorable 
---