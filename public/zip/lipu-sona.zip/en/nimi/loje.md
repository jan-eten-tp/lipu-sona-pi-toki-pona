---
sp: 󱤫
definition: red, magenta, scarlet, pink, rust-colored, reddish orange
---
<!-- loje is about reds and stuff. my favourite colour is #e63e62, which is a loje. -->