---
sp: 󱥟
definition: vertical surface; wall, board; front of something, face
---
<!-- sinpin is about vertical surfaces and things that face towards you. it's also about the fronts of things. -->