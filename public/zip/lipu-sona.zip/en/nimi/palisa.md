---
sp: 󱥊
definition: long and hard thing; branch, pole, rod, stick, spine, mast
---
<!-- palisa is things that are long and hard. they're difficult to bend, or look like they would be difficult to bend. typically a palisa would rather snap than be bent too far. -->