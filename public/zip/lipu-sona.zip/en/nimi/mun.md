---
sp: 󱤺
definition: moon, night sky object, star, celestial body
---
<!-- mun is what you see when you look up at the sky, especially at night. the most obvious of these is the moon. more broadly it's any object in space. our earth is ma, but it's also a mun. -->