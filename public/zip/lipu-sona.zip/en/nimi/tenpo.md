---
sp: 󱥫
definition: time, event, situation, moment, period, duration
---