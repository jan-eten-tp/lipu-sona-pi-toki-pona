---
sp: 󱤍
definition: negative quality; bad, unpleasant, harmful, unneeded
---
<!-- ike is everything i hate. much like pona, it's a prime example of the inherent subjectiveness of toki pona. ike isn't things that are *objectively* bad, because that's not something we can actually determine. it's about things that are bad from the speaker (or maybe someone else's) perspective. but the ike is always from someone's perspective. -->