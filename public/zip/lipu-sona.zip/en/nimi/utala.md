---
sp: 󱥱
definition: fight, compete, battle; competition, challenge; struggle, strive
---
