---
sp: 󱤃
definition: hunt, search, forage, attempt
---
<!-- - alasa is about actively seeking things and actively trying to acquire something. -->