---
sp: 󱤻
definition: fun, game, entertainment, art, play, amusing, interesting, comical, silly
---
<!-- musi are the things we do for fun. the ways that we've played and entertained ourselves throughout history. musi is fun and entertainment. -->