---
sp: 󱥴
definition: bird, flying creature, winged animal
---
