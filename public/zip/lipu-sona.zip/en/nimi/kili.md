---
sp: 󱤚
definition: fruit, vegetable, seed, mushroom
---
<!-- kili is plants and fruits and stuff that can be eaten. not necessarily ones that *you* specifically can eat, but ones that could be eaten, by some ijo out there. -->