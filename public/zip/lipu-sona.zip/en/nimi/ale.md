---
sp: 󱤄
definition: all, every, everything, entirety
number: one hundred
---
<!-- - ale is everything. it's the whole of something -->