---
sp: 󱥩
definition: motion, e.g. walking, shaking, flight, travel
preposition: to, for, going to, from the perspective of, for the purpose of
---