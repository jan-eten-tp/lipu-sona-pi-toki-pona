---
sp: 󱥓
definition: container; bag, bowl, box, cup, cupboard, drawer, folder
---
<!-- poki is something that contains stuff. usually the stuff contained is inanimate -->