---
sp: 󱥬
definition: communicate, say, think; conversation, story; language
---