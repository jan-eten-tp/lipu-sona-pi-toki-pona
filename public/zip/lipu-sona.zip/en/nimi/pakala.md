---
sp: 󱥈
definition: damage, break, botch, harm, mess up; mistake
---
<!-- pakala means fuck. -->