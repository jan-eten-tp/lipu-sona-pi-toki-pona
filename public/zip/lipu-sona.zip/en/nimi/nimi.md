---
sp: 󱥂
definition: word, name
---
<!-- nimi is words and names. -->