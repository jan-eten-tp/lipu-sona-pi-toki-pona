---
sp: 󱥑
definition: insect, bug, spider, tiny crawling creature
---
<!-- pipi are tiny little guys that crawl around. some of them fly too. -->