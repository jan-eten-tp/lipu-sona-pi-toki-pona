---
sp: 󱥯
definition: sex, to have sex with
---