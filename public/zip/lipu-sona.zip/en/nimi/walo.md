---
sp: 󱥲
definition: light-colored, white, pale, light gray, cream
---
