---
sp: 󱤪
definition: flat object; book, card, leaf, paper, document, website
---
<!-- lipu is about flat things. these flat things tend to either be bendable or good for storing information. the prototypical lipu is a piece of paper; it's bendable, it's flat, and it's great for storing knowledge! to me, all other lipu's are similar to paper in some of these ways.

a leaf is similar, because that it's flat and bendable, even if it's probably not your go-to medium to write your essay on. this website is similar, because it contains knowledge and i can't think of anything flatter than a website. sure you can't bend it, but it's so similar to paper still. -->