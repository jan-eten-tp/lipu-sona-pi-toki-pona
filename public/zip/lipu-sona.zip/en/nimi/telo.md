---
sp: 󱥪
definition: liquid; water, gasoline, soda, lava, soup, oil, ink
---