---
sp: 󱥪
definition: liquids e.g. water, gasoline, soda, lava, soup, oil, ink
---