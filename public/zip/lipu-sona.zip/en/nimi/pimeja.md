---
sp: 󱥏
definition: dark, unlit; black, purple, brown
---
<!-- pimeja is darkness and dark shades of colour. -->