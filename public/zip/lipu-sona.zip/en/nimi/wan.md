---
sp: 󱥳
definition: singular, united; combine, join, mix, fuse
number: one 
---
