---
sp: 󱤛
definition: hard object; metal, stone, wood
---
<!-- kiwen is about hardness, solid stuff. it's part of the "kiwen-ko-telo-kon" range, that covers several states of matter; solidity, semi-solidity, liquid, gaseous. -->