---
sp: 󱤧
particle: marks the start of the predicate
---