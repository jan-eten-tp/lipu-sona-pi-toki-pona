---
sp: 󱤰
definition: earth, land, soil; country, territory, world; outdoors
---
<!-- ma is about earth and land. our planet is a ma, and places on earth is ma. -->