---
sp: 󱤸
definition: back, behind, rear
---
<!-- monsi is the behind of things -->