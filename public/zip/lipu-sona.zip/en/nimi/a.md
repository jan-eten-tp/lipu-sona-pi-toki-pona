---
sp: 󱤀
particle: emphasis or emotion
---