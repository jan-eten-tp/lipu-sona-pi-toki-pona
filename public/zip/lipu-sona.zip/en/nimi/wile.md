---
sp: 󱥷
definition: want, desire, wish, require
preverb: want to
---
