---
sp: 󱥅
definition: love, have compassion for, respect, show affection to
---
<!-- olin is about strong emotional bonds. in my course i have a tendency to use it specifically to mean "love", because the course was made for my girlfriend. i was thinking about love a lot more than other things. but olin means much more than that! i olin toki pona, i olin my cat. i olin many of my friends.

the important thing to be aware of is that olin is not "like". in english you might say "i love that song!!!" for any song you sort of like, but in toki pona you'd be implying something else with "olin"; a person might assume that the song is one of your favourite songs ever, that it's very important to you, or some other strong connection. -->