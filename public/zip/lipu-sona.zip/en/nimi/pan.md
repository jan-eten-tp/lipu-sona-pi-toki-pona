---
sp: 󱥋
definition: grains, starchy foods, baked goods; rice, sorghum, bread, noodles, masa, porridge, injera
---
<!-- pan is bread and grains and stuff. -->