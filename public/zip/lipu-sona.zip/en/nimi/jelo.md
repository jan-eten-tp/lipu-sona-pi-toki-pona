---
sp: 󱤒
definition: yellow, amber, golden, lime yellow, yellowish orange
---
<!-- jelo is what it sounds like, it's yellow-y colours! to me, that includes everything from certain oranges to certain greens. -->