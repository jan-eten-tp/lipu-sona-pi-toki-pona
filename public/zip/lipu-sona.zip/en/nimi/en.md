---
sp: 󱤊
particle: between additional subjects
---