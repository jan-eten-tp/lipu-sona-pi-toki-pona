---
sp: 󱤽
definition: number
particle: ordinal number
---
<!-- nanpa is about numbers and things relating to numbers -->