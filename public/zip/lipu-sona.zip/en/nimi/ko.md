---
sp: 󱤜
definition: paste, powder, goo, sand, soil, clay; squishy, moldable
---
<!-- ko is semo-solids, things that can be shaped into something else. it can also describe stuff like sand. and it can describe soft things, like my pillow! it's part of the "kiwen-ko-telo-kon" range, that covers several states of matter; solidity, semi-solidity, liquid, gaseous. -->