---
sp: 󱥡
definition: knowledge, information, data; know, be skilled in, be wise about
preverb: know how to
---
<!-- sona is about KNOWLEDGE. it's your own expertise and the limitless amount of information that can be found in our world. it's also used as a preverb that can tell us you know how to do something. this is a little similar to ken, but the important difference is that ken is about things you are able to do right now, whereas sona is about anything you know how to do in theory, even if you may not currently have the means to do it. a construction worker might sona pali e tomo, but that doesn't mean he ken pali e tomo just whenever he wants. -->