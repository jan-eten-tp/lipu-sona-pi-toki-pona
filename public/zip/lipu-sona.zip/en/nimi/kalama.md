---
sp: 󱤕
definition: to produce sound; sound; singing, thundering, drumming, clapping, laughing, beeping
---
<!-- kalama is sounds and the act of creating sounds. -->