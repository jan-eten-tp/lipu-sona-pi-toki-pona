---
sp: 󱤕
definition: to produce a sound; recite, utter aloud
---
<!-- kalama is sounds and the act of creating sounds. -->