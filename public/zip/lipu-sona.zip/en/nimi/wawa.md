---
sp: 󱥵
definition: power, energy, strength; confident, intense, forceful; amazing, impressive
---
