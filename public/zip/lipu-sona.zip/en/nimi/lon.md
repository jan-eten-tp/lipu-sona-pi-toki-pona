---
sp: 󱤬
definition: real, true, existing, present
preposition: located at, located in
---
<!-- lon talks about the truth, our reality. it talks about things that are currently present. as a preposition it tells us where the sentence is happening.

the "where" of the sentence can be metaphorical. i could say "mi pona lon toki pona" and it would make sense for "i'm good at toki pona". the lon describes the domain of me being good. -->