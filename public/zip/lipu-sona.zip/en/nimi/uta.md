---
sp: 󱥰
definition: mouth, throat, consuming orifice
---
