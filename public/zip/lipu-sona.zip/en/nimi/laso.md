---
sp: 󱤣
definition: turquoise, blue, green, cyan, indigo, lime green
---
<!-- lots of learners struggle with laso more than the other colour words. to many, it's hard to think of the concept of blue and green as one while learning. (say something MORE USEFUL here) -->