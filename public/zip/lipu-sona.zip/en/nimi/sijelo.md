---
sp: 󱥛
definition: body, shape, physical state, torso, substance, form
---
<!-- sijelo is about bodies and torsos. it's about your physical state, but can be extended to be about representations of you in digital spaces. -->