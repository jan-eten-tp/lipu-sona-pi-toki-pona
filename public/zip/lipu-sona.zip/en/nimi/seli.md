---
sp: 󱥗
definition: hot, warm; heat, fire, flame; burn
---
<!-- seli is about warmth and fire. i've heard it be extended into other things that give feelings of warmth, like happiness, comfort, or spicy food. you can debate whether or not all of these actually make sense or not. -->