---
sp: 󱤦
definition: cold, cool, frozen; freeze; uncooked, raw
---
<!-- lete is about coldness. by extension, it can refer to things that are raw and need to be heated, like uncooked food. -->