---
sp: 󱥙
particle: indicates missing information in a question
---
