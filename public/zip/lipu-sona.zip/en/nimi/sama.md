---
sp: 󱥖
definition: same, similar, alike
preposition: similar to, same as
---
<!-- sama is a word about similarity. its main use is as a preposition, that tells us that something is similar or the same as something else. -->