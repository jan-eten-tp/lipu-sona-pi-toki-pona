---
sp: 󱤏
definition: inside, center, between, middle, midpoint, internal
---
<!-- insa is the inside of something, or the point inbetween several other things. it can also describe the stuff that is inside of something, like your the various things inside of your computer or a person's organs. -->