---
sp: 󱤆
definition: other, altered; modify, change; difference
---
<!-- ante is about differences and change. when you change things, you ante e ona. when you talk about things that have changed, those things could be ante or ijo ante. ante can also be used a lot to talk about things that are sort of besides the point; "ante la, (...)" is often used as a segue into a tangentially related point, and ante can be used to describe things which are tangentially related. -->