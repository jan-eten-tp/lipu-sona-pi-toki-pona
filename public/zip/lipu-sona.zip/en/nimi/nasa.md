---
sp: 󱤾
definition: strange, unusual, silly, abnormal, unexpected
---
<!-- nasa is about things that are a little whimsical or unexpected. it's things that dont fit an expected pattern. there's nothing inherently bad or good about something being nasa, it's just a description of how unexpected it was from your perspective -->