---
sp: 󱤅
definition: bottom, underside; below, beneath; defeat, humble, lowly
---
<!-- anpa is about the bottom part of something, the underside, the things below, but also metaphorically about inferiority. it can be used a lot in the context of games to describe the act of beating someone in the game, "mi anpa e sina", meaning that you have shown the opponent to be beneath you. it sounds a little dramatic like that though... -->