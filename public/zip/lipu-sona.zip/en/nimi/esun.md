---
sp: 󱤋
definition: trade, barter, exchange, swap, buy, sell; market, shop, fair, bazaar, place of business
---
<!-- esun is primarily about exchanging, which means it can refer to trading two items, it can refer to purchasing something or selling something.

esun also refers to places where exchange can take place. the store is obviously an esun, and so is a group where you can swap clothing you wanna get rid of with other people's clothing they wanna get rid of. -->