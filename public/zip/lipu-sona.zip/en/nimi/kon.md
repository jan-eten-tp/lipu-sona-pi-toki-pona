---
sp: 󱤝
definition: air, breath, wind; essence, spirit, soul, ghost; unseen agent
---
<!-- kon has a lot of meaning and a wide metaphorical use. primarily it's about air and wind, but ultimately it's about things we can't see but which still do something important. kon can describe someone's vibes, it can describe the deeper meaning of others's speech, it can describe 

kon is used a lot to describe things like bacteria, something we can't see but which are incredibly important to our lives.

it's part of the "kiwen-ko-telo-kon" range, that covers several states of matter; solidity, semi-solidity, liquid, gaseous. -->