---
sp: 󱥤
definition: light, shine, glow, radiance; sun, light source; brightness
---
