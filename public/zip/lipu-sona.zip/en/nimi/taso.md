---
sp: 󱥨
definition: only, exclusively
particle: but
---