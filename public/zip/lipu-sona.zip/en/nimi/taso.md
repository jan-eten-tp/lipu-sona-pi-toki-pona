---
sp: 󱥨
definition: only, exclusively
particle: marks a sentence as qualifying or contradictory; but, however
---