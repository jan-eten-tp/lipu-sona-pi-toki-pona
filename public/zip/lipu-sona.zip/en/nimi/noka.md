---
sp: 󱥃
definition: foot, leg, organ of locomotion, roots
---
<!-- noka is generally your legs or feet, or other limbs that are used for traversal, like a squid's tentacle or a bird's wings. noka is also sensible for things that are sort of acting like a typical noka. when a guy walks on his arms then his arms are kind of like noka, even though it's usually a luka. -->