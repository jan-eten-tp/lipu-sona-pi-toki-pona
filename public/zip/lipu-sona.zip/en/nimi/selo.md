---
sp: 󱥘
definition: outer layer; skin, peel, shell, bark; boundary
---
<!-- selo is about an often protective layer that's around something. stuff like tree bark and a tortoise's shell, or maybe even walls protecting a city from scary monsters or whatever. some people also like to use selo to mean hugging, as in "mi selo e sina". when you hug them, you're creating a protective layer around them. it's cute. -->