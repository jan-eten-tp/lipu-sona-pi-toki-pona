---
sp: 󱤤
definition: head, mind, brain; control, lead, guide; government, leader; rule, law
---
<!-- lawa is about the part of something that's in charge, that leads. the head is a primary example, your head contains the brain that is responsible for all of your decisionmaking. it rules over your body. lawa can also be used for other types of leaders, like the leaders of communities and nations. lawa can describe the formal norms of a society or community. lawa also describes the act of leading, of taking charge -->