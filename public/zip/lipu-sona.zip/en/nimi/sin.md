---
sp: 󱥝
definition: new, fresh, update; repeat, do again; additional, another, extra
---
<!-- sin is about things that are new in some way. when you see something for the first time, it's sin. when you create something, it's sin. when you repeat an action, you're renewing your action, "mi moku sin" - "i eat again".

things that are additional in some way are also sin. they are new to something. an old word you're unfamiliar with or that is non-standard could be described as *sin*, because it is new to you, or to what is considered standard.

if i am making food and i add something that i wouldn't normally, that's sin. a fancy restaurant chef probably doesn't feel that any of the fancy garnish he adds is sin, but to me it's still sin because it's not how i might normally eat that food. -->