---
sp: 󱤐
definition: disgusting, obscene, sickly, toxic, unclean, unsanitary
---
<!-- jaki is gross stuff. ewwwww -->