---
sp: 󱤮
definition: look, view, examine, read, watch; eye, seeing organ
preverb: to try to
---
<!-- lukin is about sight and vision, and things that can see. your eye is a lukin, and so is a webcam. lukin is NOT "looks". if "ijo li lukin pona", the thing isn't good looking, it is looking good (as in good at looking). -->