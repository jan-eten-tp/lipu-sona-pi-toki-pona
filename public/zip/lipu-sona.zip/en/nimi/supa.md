---
sp: 󱥥
definition: flat horizontal surface; bed, floor, desk, plate, table, platform, stage
---
