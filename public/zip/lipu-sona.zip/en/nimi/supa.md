---
sp: 󱥥
definition: flat horizontal surface, especially to put or rest things on e.g. bed, floor, desk, plate, table, platform, stage
---
