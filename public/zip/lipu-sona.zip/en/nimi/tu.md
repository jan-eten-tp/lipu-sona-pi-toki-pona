---
sp: 󱥮
definition: separate, divide, split
number: two
---