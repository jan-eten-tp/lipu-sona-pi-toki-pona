---
sp: 󱥄
particle: vocative, imperative, or optative
---