---
sp: 󱤗
definition: plant, vegetation; herb, leaf
---
<!-- kasi is plants and mushrooms and stuff. it's the stuff you find growing outside; the grass, the flowers, the trees, the moss. -->