---
sp: 󱥕
definition: "to interact with the book Toki Pona: The Language of Good by Sonja Lang"
---