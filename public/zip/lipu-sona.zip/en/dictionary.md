---
title: "dictionary"
navigation-exclude: true
---

short definitions are taken from [lipu Linku](https://linku.la/), with some changes by me.

long definitions written by me.
<br>

:dictionary{lang="en"}
