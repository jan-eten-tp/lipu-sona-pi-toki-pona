hello! if you're reading this, youve maybe decided to translate my course! thanks!!!

i recommend starting at index.md, then translating the definitions in the nimi/ folder and translating from 0.introduction.md to 21.ur-done.md, THEN .optional.md if u want a pdf version of ur course. good luck and thank u, i appreciate it!!