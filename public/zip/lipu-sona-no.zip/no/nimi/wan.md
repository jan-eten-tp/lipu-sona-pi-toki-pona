---
sp: 󱥳
definition: forent, enhetlig; kombinere, bli med, blande, smelte sammen
number: en 
---
