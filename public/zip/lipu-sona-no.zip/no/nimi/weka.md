---
sp: 󱥶
definition: fraværende, borte, fjern; å fjerne, bli kvitt
---
