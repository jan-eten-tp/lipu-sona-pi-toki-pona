---
sp: 󱤂
definition: ikke, ingenting, nei
number: "null"
---
<!-- ala is about nothing. well, it's about something. but the something is nothing. as a modifier it's especially great, as it helps us specify what we're NOT talking about. something that's ike ala could be many things, but one thing's for sure: it's not ike.

there's still sort of an implication it's gonna be something that's in the same "category" as ike, though. maybe it's not ike, but pona! but it's probably less likely for it to be not ike, but jan, because if you're talking about a jan there's not much chance that they'd have been confused for ike. so in that way, it tells us more than just what we're not talking about, but also about the type of thing that we're talking about. -->