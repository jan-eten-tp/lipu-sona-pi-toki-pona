---
sp: 󱥉
definition: arbeid, praksis; skape, bygge, designe
---
<!-- pali is about activities that take effort and work. if you're doing something mindlessly with no effort, that's not really a type of pali. but if you're striving towards a goal, creating something, etc., that's pali. -->