---
sp: 󱥷
definition: ønske, kreve
preverb: å ville, å ønske å, å ha lyst til
---
