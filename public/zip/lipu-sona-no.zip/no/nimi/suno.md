---
sp: 󱥤
definition: lys, glød, utstråling; sol, lyskilde
---