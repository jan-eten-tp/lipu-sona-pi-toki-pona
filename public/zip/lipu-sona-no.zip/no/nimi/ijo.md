---
sp: 󱤌
definition: ting, fenomen, objekt, noe; skapning, noen
---
<!-- everything and everyone is ijo. it's the most generic term possible. ijo is essentially like a placeholder where more specific words would normally go. "ijo li ijo e ijo" means "something did something to something".

ijo is also great as a neutral term to refer to others. lots of people don't identify with jan, and it varies how narrow people's jan usage is, so the safer bet is to use ijo to others when you don't know what else to use. be nice to people and refer to them how they want to be referred to. -->