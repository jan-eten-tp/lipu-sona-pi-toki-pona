---
sp: 󱤘
definition: evne, tillatelse; mulighet, kanskje; tillate
preverb: å kunne
---
<!-- ken talks about ability, skills, possibilities. when sina ken e ijo, you give that ijo some sort of ability. usually, it's the permission to do something.

if you know how to do something but can't do it, that's not ken. ken is about what's possible for you in the present. -->