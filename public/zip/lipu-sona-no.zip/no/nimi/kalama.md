---
sp: 󱤕
definition: lyd, støy; å lage lyd
---
<!-- kalama is sounds and the act of creating sounds. -->