---
sp: 󱥰
definition: munn, hals
---
