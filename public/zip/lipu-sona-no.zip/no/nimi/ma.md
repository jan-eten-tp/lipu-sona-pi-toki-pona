---
sp: 󱤰
definition: jord, landareal; land, nasjon, territorium, verden; utendørs
---
<!-- ma is about earth and land. our planet is a ma, and places on earth is ma. -->