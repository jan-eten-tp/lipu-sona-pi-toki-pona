---
sp: 󱤑
definition: menneske, person, noen
---
<!-- jan is a word that at the very least describes human beings, but to most people it describes more than just that too. the tricky thing is that it's hard to make a clear definition of what additional things jan covers, because most lines one might try to draw are problematic or exclusionary. 

jan is human beings? well, that's like half the toki pona community gone from your jan definition. if you want that, cool i guess. jan is sentient beings? sentience is a very vague and iffy concept with a lot of baggage attached, so maybe not. jan are others who can theoretically communicate with you? that definition doesn't even cover every human being, and is it a useful distinction to draw?

i try to use jan broadly myself, but i have yet to find a concrete line to draw of what is jan or not. maybe ijo is a better choice in a lot of situations? it lacks any of the baggage jan does just for including "human" in its definition. -->