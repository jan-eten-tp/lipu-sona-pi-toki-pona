---
sp: 󱤉
particle: markerer direkte objektet
---