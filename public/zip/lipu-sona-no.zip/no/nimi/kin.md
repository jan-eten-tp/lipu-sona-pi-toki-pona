---
sp: 󱥹
definition: også, i tillegg; faktisk
---
<!-- kin tells us something is in addition to something else. whatever you modify with kin, you're saying that there are other things in addition to what you've modified with kin as well. "mi kin li lukin" means "i also (in addition to others) am looking", whereas "mi lukin kin" means "i am also looking (in addition to other things im doing)". some people might also interpret a kin at the end of the sentence as applying to the whole sentence.

some use kin as a sentence starter for sentences that add additional information, sort of starting a sentence with english "also,". "ale li musi. kin, ona li pona" - "everyone is having fun. also, they're nice!".  -->