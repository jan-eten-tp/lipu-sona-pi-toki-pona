---
sp: 󱤇
particle: skiller flere muligheter, og erstatter en partikkel/preposisjon
---
<!-- my course's lesson on anu used to be called "anu (it's fucked up)". this was because, at the time, i thought that anu was this very poorly defined thing that everyone was using in lots of different conflicting ways and it was like the wild west! i thought this mostly because there's a tendency where people just don't want to even try to teach anu, because they are so unsure of themselves and their own usage. when i got around to making my course, i felt as if i needed to define anu all on my own, like there was no real usage behind it.

what i've later discovered, though, is that almost everyone uses anu the same way. i can try and try to find examples of anyone who uses it differently than how my course describes it and it's hard! there are very *slight* differences, such as some people putting anu *before* particles instead of replacing them with anu. but like, ultimately everyone is using anu very similarly. 

if you currently are or ever become a skilled toki pona speaker who spends your time teaching others, im pleading with you to please just teach anu. it's not that scary. -->