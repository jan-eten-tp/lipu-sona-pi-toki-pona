---
sp: 󱥙
particle: manglende informasjon i et spørsmål
---
