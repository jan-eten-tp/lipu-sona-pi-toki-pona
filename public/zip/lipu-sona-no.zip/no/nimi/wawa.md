---
sp: 󱥵
definition: kraft, energi, styrke; selvsikker, intens, kraftfull; fantastisk, imponerende
---
