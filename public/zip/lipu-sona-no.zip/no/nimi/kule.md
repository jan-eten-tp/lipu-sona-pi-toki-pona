---
sp: 󱤞
definition: farge; kategori, sjanger, smak
---
<!-- primarily kule is about colours, but its meaning is often extended to describe a broader category. it's about how we colour everything in our lives into specific categories. -->