---
sp: 󱥦
definition: søtt, søt, bedårende
---