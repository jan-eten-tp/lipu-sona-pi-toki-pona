---
sp: 󱥨
definition: bare, utelukkende
particle: men
---