---
sp: 󱥓
definition: pose, bolle, boks, kopp, skap, skuff, mappe
---
<!-- poki is something that contains stuff. usually the stuff contained is inanimate -->