---
sp: 󱤥
definition: stoff, tekstil; skjult, hemmelig, dekket, privat
---
<!-- len is about covering stuff up. it's about clothing and secrecy.  -->