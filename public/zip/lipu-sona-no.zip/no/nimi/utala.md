---
sp: 󱥱
definition: kjempe, konkurrere, slåss; konkurranse, utfordring; streve
---
