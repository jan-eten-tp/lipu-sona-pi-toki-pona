---
sp: 󱥍
particle: omgrupperer adjektiv
---