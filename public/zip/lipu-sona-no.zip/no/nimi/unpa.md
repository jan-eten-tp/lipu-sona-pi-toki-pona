---
sp: 󱥯
definition: sex
---