---
sp: 󱥁
definition: dette, det, disse, de
---
<!-- ni is demonstrative pronouns. it's like when you point at stuff and say "this, this right here" (or "that right there"). you can also point to broader ideas instead of specific things. -->