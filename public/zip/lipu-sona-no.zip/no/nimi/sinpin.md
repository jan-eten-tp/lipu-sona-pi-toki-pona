---
sp: 󱥟
definition: vertikal overflate; vegg, bord; forsiden av noe, fjes
---
<!-- sinpin is about vertical surfaces and things that face towards you. it's also about the fronts of things. -->