---
sp: 󱥀
definition: bump, knapp, fjell, nese
---
<!-- nena is bumps. things that stick out of something. nenas can be sharp or rounded. -->