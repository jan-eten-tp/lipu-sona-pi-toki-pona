---
sp: 󱥞
definition: andrepersonspronomen (du, deg, dere)
---
<!-- you is a second-person pronoun. it talks about you and y'all, the group you're part of. -->