---
sp: 󱥔
definition: positiv egenskap; god, snill, hyggelig, hjelpsom, vennlig, nyttig, fredelig
---
<!-- pona is everything i like. it's a prime example of the inherent subjectiveness of toki pona. pona is basically never about "objectively" good things, it's basically always about what is good from the speaker's (or maybe someone else's) perspective. things are always pona based on *someone*'s subjective experience of the world. this is why the typical way to talk about things you like in toki pona is simply to say that it's pona. -->