---
sp: 󱤼
definition: mange, flere, veldig; mengde
number: tjue
---
<!-- mute can be used to talk about amounts, and it's also used to talk about things that are many. keep in mind that what counts as a lot, many, or much is relative! if someone has 3 houses you could say "ona li jo e tomo mute", because that's a lot of houses! but if someone has 3 plushies thats not really that much. get more plushies -->