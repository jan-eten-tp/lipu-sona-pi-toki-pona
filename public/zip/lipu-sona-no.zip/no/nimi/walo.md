---
sp: 󱥲
definition: lys, hvit, blek, lys grå
---
