---
sp: 󱥆
definition: tredjepersonspronomen (han, hun, det, de)
---
<!-- ona is third-person pronouns! it's like he, she, it, they in english! with ona, whoever i am referring to is not part of either my or your group. it's someone separate from you and us -->