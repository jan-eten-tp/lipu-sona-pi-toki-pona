---
sp: 󱤯
definition: hull, grop, hule, døråpning, vindu, portal
---
<!-- lupa is holes and entrances. lupas tend to either be an opening where their is meant to be something, or it's something which takes you from one place to another. one could take you from ma to tomo, for example. -->