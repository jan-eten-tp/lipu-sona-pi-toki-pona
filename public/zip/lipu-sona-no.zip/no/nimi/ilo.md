---
sp: 󱤎
definition: verktøy, redskap, maskin, enhet
---
<!-- ilo is tools! it's useful things! it's machines!

ilo are generally things that are useful to you for some task, or that can be useful for tasks. when you refer to things as ilo, you're focused on the object's ability to fulfill tasks. electronic devices can pretty much always be described as an ilo because of the countless of tasks they can fulfill.

my course could be an ilo to you. the device you're on right now is probably an ilo. vehicles are ilo. -->