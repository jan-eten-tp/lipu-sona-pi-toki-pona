---
sp: 󱤴
definition: førstepersonspronomen (jeg, meg, vi, oss)
---
<!-- mi is a first-person pronoun. it talks about me and us, the group i'm speaking for. -->