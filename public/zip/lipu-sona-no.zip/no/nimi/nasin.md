---
sp: 󱤿
definition: metode, prosess, en lære, tradisjon; sti, vei
---
<!-- nasin talks about the paths we take in life towards our goals. this includes the physical roads we travel and the various guidelines that we follow in our decisionmaking, the methods we use to achieve things. the way that you speak toki pona is an example of a nasin. -->