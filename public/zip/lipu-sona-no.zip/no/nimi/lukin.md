---
sp: 󱤮
definition: se, undersøke, lese; øye, seende organ
preverb: å forsøke, å prøve
---
<!-- lukin is about sight and vision, and things that can see. your eye is a lukin, and so is a webcam. lukin is NOT "looks". if "ijo li lukin pona", the thing isn't good looking, it is looking good (as in good at looking). -->