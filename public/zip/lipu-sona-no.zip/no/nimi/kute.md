---
sp: 󱤠
definition: øre; å høre, lytte
---
<!-- kute is about hearing things. it can also be used with a meaning like "to pay attention, to obey" but this meaning only makes sense when paying attention or obeying involves listening. if you want to tell someone to pay attention to something which is purely visual, then "o lukin!" might be a better translation. -->