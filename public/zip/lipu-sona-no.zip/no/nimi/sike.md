---
sp: 󱥜
definition: sirkel, kule, spiral, rund greie, ball, hjul; noe som gjentar seg, syklus, bane, løkke
---
<!-- sike is circular things. obviously this includes like balls and wheels. it also extends to cycles, things that repeat at intervals. years and days and weeks are all types of sike. the earth's orbit around the sun is sike. -->