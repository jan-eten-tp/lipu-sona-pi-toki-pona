---
sp: 󱤲
definition: penger, valuta; ting av verdi f.eks. gull, investering, husdyr
---
<!-- mani are things that are valuable in some way, or things you want to use for trade. money and currency is probably mani to most. to a farmer, their livestock might be mani. a miner might call gold kiwen, but many others might call it mani. -->