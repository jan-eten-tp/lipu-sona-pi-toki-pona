---
sp: 󱤸
definition: bak, bakside, rygg
---
<!-- monsi is the behind of things -->