---
sp: 󱤈
definition: bli, vente, pause; beskytte, holde trygt; fortsette
preverb: fortsette å
---
<!-- awen is about continuation and preservation. when you awen, you are staying as you are. maybe that means you're continuing to play minecraft. maybe it means that you're staying still and doing nothing. awen can describe pauses, but mostly in the sense that when you pause something, everything will remain the way it was. it doesn't really describe the "stop" aspect of pausing.

when you awen other things, it means you're ensuring that this thing will remain as it was. if you awen a house then you're making sure the house doesn't degrade. if you awen a broken picture then you're making sure it will always remain the same amount of broken. the picture frame will forever be cracked, but there at least won't be any more cracks. -->