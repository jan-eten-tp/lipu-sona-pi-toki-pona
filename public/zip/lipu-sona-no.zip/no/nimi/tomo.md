---
sp: 󱥭
definition: innendørs plass, ly; rom, bygning, hjem, telt, hytte
---