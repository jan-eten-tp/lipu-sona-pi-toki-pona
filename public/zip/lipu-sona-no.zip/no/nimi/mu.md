---
sp: 󱤹
definition: støy eller kommunikasjon fra dyr; vokalisering uten tale
---
<!-- mu is meow -->