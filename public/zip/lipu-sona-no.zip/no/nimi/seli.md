---
sp: 󱥗
definition: varm; varme, ild, flamme; brenne
---
<!-- seli is about warmth and fire. i've heard it be extended into other things that give feelings of warmth, like happiness, comfort, or spicy food. you can debate whether or not all of these actually make sense or not. -->