---
sp: 󱤡
particle: mellom kontekst og hovedsetning
---