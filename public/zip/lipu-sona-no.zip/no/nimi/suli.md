---
sp: 󱥣
definition: stor, tung, lang, høy, bred; viktig, relevant
---
<!-- suli is about large things. things that take up a lot of space, either literally or metaphorically. a tall person is suli, but so is a short important person. -->