---
sp: 󱥚
definition: opp, topp, over, høyeste del; guddommelig, hellig, overnaturlig; fantastisk, inspirerende, utmerket
---
<!-- sewi is both about the sky and things above, and about divine or incredible things. the idea of things that are high up, supernatural things, and incredible stuff, are all interconnected. -->