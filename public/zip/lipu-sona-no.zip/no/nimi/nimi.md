---
sp: 󱥂
definition: ord, navn
---
<!-- nimi is words and names. -->