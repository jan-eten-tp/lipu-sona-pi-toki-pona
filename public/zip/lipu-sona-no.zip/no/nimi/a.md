---
sp: 󱤀
particle: vektlegging, følelse, eller bekreftelse
---