---
sp: 󱥎
definition: følelse, mening; hjerte
---
<!-- pilin is about feelings, opinions, emotions. when you think about things it's very often a type of pilin. pilin also refers to where emotions are metaphorically located, the heart. -->