---
sp: 󱥕
definition: "å gjøre noe med boken Toki Pona: The Language of Good av Sonja Lang"
---