---
sp: 󱤭
definition: hånd, arm, taktil lem, gripende lem
number: fem
---
<!-- luka is generally your hand, or like other limbs that grab things, like a squid's tentacle. luka is also sensible for things that are sort of acting like a typical luka. when a cat baps something with its front paw its front paw is kind of like a luka, even though it's usually a noka. -->