---
sp: 󱤙
preposition: ved bruk av, ved hjelp av
---
<!-- kepeken is a preposition that tells us by what means we're doing something. you might've noticed kepeken sticks out a little, being the only preposition that only has a definition as a preposition. some people do use kepeken as a regular word, usually meaning "to use; usage". but most prefer not to do this, because "to use" is exactly the same as the preposition meaning anyways, and "usage" is better covered by other words.  -->