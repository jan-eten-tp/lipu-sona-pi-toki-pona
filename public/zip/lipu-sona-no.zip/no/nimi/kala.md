---
sp: 󱤔
definition: fisk, sjødyr, svømmende skapning
---
<!-- kala is a creature that hangs out in the water. most of them live there! it's also fun to use kala to describe just anything that's in the water, just like waso is fun to use for anything that's flying. -->