---
sp: 󱤃
definition: jakte, lete, forsøk
---
<!-- - alasa is about actively seeking things and actively trying to acquire something. -->