---
sp: 󱤷
definition: død; drepe
---
<!-- moli is death and dying. you generally can't recover from moli unless you're a gamer who can't die they just respawn -->