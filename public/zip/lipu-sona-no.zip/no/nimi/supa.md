---
sp: 󱥥
definition: flat horisontal overflate, noe å sette eller hvile greier på; seng, gulv, tallerken, bord, plattform, scene
---
