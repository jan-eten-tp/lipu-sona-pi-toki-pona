---
sp: 󱥈
definition: skade, knekke, feile, rote til; feil
---
<!-- pakala means fuck. -->