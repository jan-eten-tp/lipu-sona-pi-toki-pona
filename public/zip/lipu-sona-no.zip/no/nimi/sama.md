---
sp: 󱥖
definition: samme, like, lignende
preposition: ligner på, er lik som
---
<!-- sama is a word about similarity. its main use is as a preposition, that tells us that something is similar or the same as something else. -->