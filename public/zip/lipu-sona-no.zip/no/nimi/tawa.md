---
sp: 󱥩
definition: bevegelse; gå, riste, fly, reise
preposition: til, for, gå til, fra perspektivet til, med formål å
---