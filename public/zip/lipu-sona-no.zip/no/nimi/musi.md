---
sp: 󱤻
definition: moro, spill, underholdning, kunst, lek, morsomt, interessant, komisk, tull
---
<!-- musi are the things we do for fun. the ways that we've played and entertained ourselves throughout history. musi is fun and entertainment. -->