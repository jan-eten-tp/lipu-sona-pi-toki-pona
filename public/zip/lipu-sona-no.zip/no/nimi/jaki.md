---
sp: 󱤐
definition: ekkelt, uanstendig, giftig, skittent, uhygienisk
---
<!-- jaki is gross stuff. ewwwww -->