---
sp: 󱥬
definition: kommunisere, si, tenke; samtale, historie; språk
---