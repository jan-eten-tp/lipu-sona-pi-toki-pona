---
sp: 󱤓
definition: holde, bære, inneholde, eie
---
<!-- jo is about ownership, possession, or physically holding things. all of these are the same thing. -->