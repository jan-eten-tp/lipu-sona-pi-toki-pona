---
sp: 󱥴
definition: fugl, flygende skapning, bevinget skapning
---
