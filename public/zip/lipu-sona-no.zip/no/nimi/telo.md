---
sp: 󱥪
definition: væsker; vann, bensin, brus, lava, suppe, olje, blekk
---