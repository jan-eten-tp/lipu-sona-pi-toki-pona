---
sp: 󱥠
definition: bilde, representasjon, symbol, skrift
---
<!-- sitelen is primarily about images and writings, but more broadly it's about symbols, things that represent something else. what i'm writing here represents language, speech, communication. a picture of a cute kitty yawning represents that cute kitty yawning. a statue might be a type of sitelen too, even if it's not the most common way to describe statues. -->