---
sp: 󱥑
definition: insekt, edderkop, liten krypende skapning
---
<!-- pipi are tiny little guys that crawl around. some of them fly too. -->