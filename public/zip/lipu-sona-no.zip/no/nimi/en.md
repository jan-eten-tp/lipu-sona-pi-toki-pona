---
sp: 󱤊
particle: mellom ytterlige subjekter
---