---
sp: 󱥌
definition: gi, sende; gave
---
<!-- pana is the act of giving, releasing, emitting. you can give things metaphorically, like good feelings. -->