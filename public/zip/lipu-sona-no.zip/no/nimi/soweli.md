---
sp: 󱥢
definition: lodne skapninger, landdyr, beist
---
<!-- soweli are creatures. they're usually fluffy or furry, move on 4 legs, and a lot of them move pretty fast (but not all). to some people, soweli can be both this specific type of animal, and a generic term for all animals. -->