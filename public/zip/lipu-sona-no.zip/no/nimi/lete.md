---
sp: 󱤦
definition: kald, kjølig, frossen; fryse; ukokt, rå
---
<!-- lete is about coldness. by extension, it can refer to things that are raw and need to be heated, like uncooked food. -->