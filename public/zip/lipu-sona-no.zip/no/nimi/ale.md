---
sp: 󱤄
definition: alt, alle, helheten
number: et hundre
---
<!-- - ale is everything. it's the whole of something -->