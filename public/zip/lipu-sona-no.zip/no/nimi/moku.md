---
sp: 󱤶
definition: spise, drikke, svelge; mat, spiselig greie
---
<!-- moku is the act of eating and the things we eat. it doesn't necessarily have to be about things living people eat specifically, you could call the gas your car needs to run moku. but you are sort of anthropomorphizing your car when you do that. -->