---
sp: 󱤟
definition: gruppe, fellesskap, samfunn, selskap, nasjon, samling, lag, publikum
---
<!-- kulupu is about groups of things. it's used a lot to refer to communities of people, but also companies, wider society, countries, or sometimes collections of things. my movie collection is a kulupu. me and the people i play games with are a kulupu. there are many kulupu pi toki pona out there.

kulupu is also often used by plural systems to describe themselves as a collective rather than a single person. -->