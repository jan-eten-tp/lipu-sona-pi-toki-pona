---
sp: 󱥐
definition: fullføre, stoppe forhindre; lukke, deaktivere, skru av; fortid; kant, slutt, konklusjon
---
<!-- pini is the end. it's when something stops, when it's finished. pini can describe the past, the time that contains all things that are finished. pini can be the act of stopping something, like ending someone's speech or turning off the light -->