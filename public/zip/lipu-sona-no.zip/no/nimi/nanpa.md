---
sp: 󱤽
definition: tall
particle: ordenstall
---
<!-- nanpa is about numbers and things relating to numbers -->