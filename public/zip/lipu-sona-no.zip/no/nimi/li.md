---
sp: 󱤧
particle: markerer starten på predikatet
---