---
sp: 󱥄
particle: vokativ, imperativ, eller optativ
---