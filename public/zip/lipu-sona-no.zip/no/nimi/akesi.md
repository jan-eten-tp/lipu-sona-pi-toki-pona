---
sp: 󱤁
definition: reptil, amfibie, krypende skapning
---
<!-- akesi are those slithery and crawly creatures that often feel scaly or cold. some of them like to hang out in water, but go on land a lot too. lots of them only hang out on land. -->