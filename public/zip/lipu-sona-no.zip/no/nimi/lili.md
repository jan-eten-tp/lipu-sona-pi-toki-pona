---
sp: 󱤨
definition: liten, kort, ung; få; et stykke, en del
---
<!-- lili is about things that are relatively small. obviously that refers to that which is literally small, but it can also refer to pieces of things. lili is also often used for small amounts, so "jan lili" could mean either "small person" or "a few people". -->