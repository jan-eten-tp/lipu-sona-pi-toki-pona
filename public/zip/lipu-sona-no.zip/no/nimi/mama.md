---
sp: 󱤱
definition: forelder, forfader; skaper, opphavsmann; forsørger, verge
---
<!-- mama is about nurture, parenting, care. obvious examples are parents and other types of parent-figures. but mama can also share some space with the word pali. for example, sonja is often called "mama pi toki pona" because she created it. it would also be correct to say "jan pali pi toki pona", but the usage of the word mama here signifies the amount of effort and dedication she's put into creating and developing this language. -->