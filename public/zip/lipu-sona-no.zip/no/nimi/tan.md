---
sp: 󱥧
definition: årsak, opphav, grunn
preposition: fra, fordi
---