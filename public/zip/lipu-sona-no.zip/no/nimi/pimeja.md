---
sp: 󱥏
definition: mørk, ubelyst; svart, lilla, brun
---
<!-- pimeja is darkness and dark shades of colour. -->