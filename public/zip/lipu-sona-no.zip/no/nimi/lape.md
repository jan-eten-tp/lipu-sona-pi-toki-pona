---
sp: 󱤢
definition: søvn, hvile, pause fra aktivitet eller arbeid
---
<!-- lape is about rest! it's used much to refer to extended rest such as sleeping, but can also be used about just chilling. playing games after a long day of work or staring blankly into the air for 2 hours after spending way too long on a math assignment is lape. -->