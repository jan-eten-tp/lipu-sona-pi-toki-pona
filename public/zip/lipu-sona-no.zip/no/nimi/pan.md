---
sp: 󱥋
definition: korn, stivelsesholdig mat, bakevarer; ris, brød, nudler, grøt
---
<!-- pan is bread and grains and stuff. -->