---
sp: 󱥮
definition: skille, dele, splitte
number: to
---