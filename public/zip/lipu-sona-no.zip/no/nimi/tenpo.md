---
sp: 󱥫
definition: tid, hendelse, situasjon, øyeblikk, periode, varighet
---