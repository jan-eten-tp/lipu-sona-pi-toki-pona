---
title: lipu sona mi pi toki pona
language: toki Nosiki / norsk # name of language in toki pona / name of language in the language
lang: "no"
author: soweli Sika # this is the name you'd like to be credited with
authorlink: # something you'd like your name to link to
previous: forrige
index: indeks
next: neste
particle: partikkel
preverb: hjelpeverb
preposition: preposisjon
number: tall
---

::index-layout

  ::bg-box
  ## sider
  <!-- this will automatically generate the list of courses -->
  :lesson-list{:lang="lang" :type="lesson"}
  ::

#right-side

  ::bg-box
  ## andre språk
  <!-- this will automatically generate the list of languages -->
  :language-list{:lang="lang"}
  ::

<br />

  ::bg-box
  ## ressurser

  - de fleste definisjonene er fra [lipu Linku](https://linku.la/)
  - jeg brukte disse ressursene når jeg var usikker:
    - [nasin toki av jan Juli](https://github.com/kilipan/nasin-toki)
    - [lipu pu av jan Sonja](https://tokipona.org/)
  - andre gode kurs:
    - [gregdan sitt kurs](https://mun.la/toki-pona/)
    - [devurandom sitt kurs](https://lipu-sona.pona.la/)
  ::

::
